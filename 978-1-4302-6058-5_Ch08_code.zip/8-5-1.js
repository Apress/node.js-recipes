/**
* Communicating Server Events
*/

var app = require('http').createServer(connectHandler),
   	io = require('socket.io').listen(app),
   	fs = require('fs');

app.listen(8080);

function connectHandler (req, res) {
  fs.readFile(__dirname + '/8-5-1.html',
  function (err, data) {
    if (err) {
      res.writeHead(500);
      return res.end('Error loading 8-5-1.html');
    }

    res.writeHead(200);
    res.end(data);
  });
}

var members
io.sockets.on('connection', function (socket) {
  // console.log(socket);
  socket.broadcast.emit('big_news'); // Emits to all others except this socket.
  socket.emit('news', { hello: 'world' });
  socket.on('my other event', function (data) {
    console.log(data);
  });
});
