var wsServ = require('websocket').server,
    http = require('http'),
    sox = {},
    idx = 0;

var server = http.createServer(function(request, response) {
    response.writeHead(404);
    response.end();
});
server.listen(8080, function() {
});

ws = new wsServ({
    httpServer: server,
    autoAcceptConnections: false
});

function originIsAllowed(origin) {
    //Check here to make sure we're on the right origin
    return true;
}

var getNextId =  (function() {
    var idx = 0;
    return function() { return ++idx; };
})();

ws.on('request', function(request) {
    if (!originIsAllowed(request.origin)) {
        request.reject();
        console.log((new Date()) + ' Connection from origin ' + request.origin + ' rejected.');
        return;
    }
    var connection = request.accept('draw-protocol', request.origin);
    connection.socketid = getNextId();
    connection.sendUTF("socketid_" + connection.socketid);
    console.log(connection.socketid);
    sox[connection.socketid] = connection;
    connection.on('message', function(message) {

        if (message.type === 'utf8') {
            sendToAll(JSON.parse(message.utf8Data), 'utf8');
        }
        else if (message.type === 'binary') {
            connection.sendBytes(message.binaryData);
        }
    });
    connection.on('close', function(reasonCode, description) {
        delete sox[connection.socketid];
    });
});

function sendToAll(text, type) {

    for (var socket in sox) {
        if (type === 'utf8' && text.socketid !== socket) {
            sox[socket].sendUTF(JSON.stringify(text));
        }
     
    }
}
