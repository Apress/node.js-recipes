

var http = require('http');


var server = http.createServer(function(req, res) {
	debugger;
	res.end('hello world');
});

server.listen(8888);
