/**
* Logging information to your console.
*/

console.time('timer');
console.log('hey %s', 'there');
console.info('info');
console.warn('warn');
console.error('error');
console.dir(console);
console.trace(console.error('traced'));
console.error(new Error('error log').stack);
console.assert(true !== false, 'true equals false');
console.timeEnd('timer');