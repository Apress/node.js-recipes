/** 
* calc 
*/

var calc = module.exports = {
	add: function(a, b) {
		return a + b;
	},
	subtract: function(a, b) {
		return a - b;
	}
};