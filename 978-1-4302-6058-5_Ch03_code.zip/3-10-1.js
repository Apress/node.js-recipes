/**
* Watching files for modifications
*/
var fs = require('fs'),
	path = '3-10/file.txt';

fs.watchFile(path, function(current, previous) {
	for (var key in current) {
		if (current[key] !== previous[key]) {
			console.log(key + ' altered. prev: ' + previous[key] + ' curr: ' + current[key]);
		}
	}
});

fs.watch(path, function(event, filename) {
	if (filename) {
		console.log(filename + ' : ' + event);
	} else {
		//Macs don't pass the filename
		console.log(path + ' : ' + event);
	}
});

// not existent size: 0  atime:  mtime: Wed Dec 31 1969 19:00:00 GMT-0500 (EST)