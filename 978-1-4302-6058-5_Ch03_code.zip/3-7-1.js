/**
* Moving files
*/
var fs = require('fs'),
		origPath,
		newPath,
		args = process.argv;

/*
if (args.length !== 4) {
	throw new Error('Invalid Arguments');
} else {
	origPath = args[2];
	newPath = args[3];
}
*/
/*

// move file asynchronously from tmp to save
fs.rename(origPath, newPath, function(err) {
	if (err) throw err;
});

//Synchronous
fs.renameSync(origPath, newPath);
*/
// CHild process => more in chapter 5
var child = require('child_process');
child.exec('mv 3-7/tmp/awesome.gif 3-7/save/awesome.gif', function(err, stdout, stderr) {
	console.log('out: ' + stdout);
	if (stderr) throw stderr;
	if (err) throw err;
});
