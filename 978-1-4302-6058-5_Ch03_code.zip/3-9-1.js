/**
* Altering file permissions
*/

var fs = require('fs'),
	file = '3-9/file.txt';

//CHANGING MODES chmod
//hidden file
//-rwSr-S--T 1 cgack cgack 4 May  5 11:50 file.txt
fs.chmod(file, 4000, function(err) {
	if (err) throw err;
});
//individual read
//--w------- 1 cgack cgack 4 May  5 11:50 file.txt
fs.chmod(file, 0200, function(err) {
	if (err) throw err;
});
//individual execute
//---x------ 1 cgack cgack 4 May  5 11:50 file.txt
fs.chmod(file, 0100, function(err) {
	if (err) throw err;
});
//individual read + execute
//--wx------ 1 cgack cgack 4 May  5 11:50 file.txt
fs.chmod(file, 0300, function(err) {
	if (err) throw err;
});
//full control
fs.chmod(file, 0777, function(err) {
	if (err) throw err;
});

//CHANGING OWNERS chown
// requires root access
//--wx------ 1 root root 4 May  5 11:50 file.txt
fs.chown(file, 0 /* root */, 0, function(err) {
	if (err) throw err;
});

//--wx------ 1 cgack cgack 4 May  5 11:50 file.txt
fs.chown(file, 1000, 1000, function(err) {
	if (err) throw err;
});