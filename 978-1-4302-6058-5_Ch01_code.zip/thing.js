/**
* Exports a description of the thing
*/
exports.describe = function() {
	return 'I\'m a thing.';
};

exports.describe = function() {
	return 'I\'m a ' + aWhat() + '.';
};

var aWhat = function() {
	return 'thing';
};