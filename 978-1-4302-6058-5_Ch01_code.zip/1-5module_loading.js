/**
* main.js - module loading
*/

    // First we require 'http' which is a native Node.js Module      
var http = require('http'), 

    // load a module with an extension Node.js has not trouble with this
    modA = require('./aModule.js'), 

    // Load ambiguous filename from subdirectory load bModule.js fine
    modB = require('./subfolder/bModule'),

    // Load index.js from subdirectory 
    sub = require('/subfolder/'),

    // not a file or native module
    // Error: Cannot find Module 'cheese'
    missing = require('cheese'); 