/**
* 
*/
var describeModule = require('./describe.js');

console.log(describeModule.describe());