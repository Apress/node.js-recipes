/**
* Desc module with private method
*/
var _getType = function() {
	return 'CommonJS Module';
};

exports.describe = function() {
	return 'I am a ' + _getType();
};