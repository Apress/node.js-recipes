/**
* Common JS Module
*/

var type = 'CommonJS Module';

var myModule = module.exports = {
	describe: function() {
		return 'I\'m a CommonJS Module';
	},

	getType: function() {
		return 'I\'m a ' + type;
	},

	greet: function(name) {
		return 'Hello ' + name;
	}

};