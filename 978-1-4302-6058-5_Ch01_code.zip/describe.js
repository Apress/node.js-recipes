/**
* Describe module
*/

exports.describe = function() {
	return 'I am a CommonJS Module';
};