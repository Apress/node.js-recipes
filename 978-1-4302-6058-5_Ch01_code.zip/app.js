var myModule = require('./module.js');

console.log(myModule.describe());

console.log(myModule.getType());

console.log(myModule.greet('Cory'));