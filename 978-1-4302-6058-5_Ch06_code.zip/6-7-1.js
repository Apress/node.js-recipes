/**
* using TLS
*/

var tls = require('tls'),
    fs = require('fs');

var options = {
    key: fs.readFileSync('srv-key.pem'),
    cert: fs.readFileSync('srv-cert.pem')
};

tls.createServer(options, function(s) {
    s.write('yo');
    s.pipe(s);
}).listen(8888);
    

