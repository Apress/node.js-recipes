/**
* tls connection
*/

var tls = require('tls'),
    fs = require('fs');

var options = {
    key: fs.readFileSync('privatekey.pem'),
    cert: fs.readFileSync('certificate.pem'),
    ca: fs.readFileSync('srv-cert.pem')
};

var connection = tls.connect(8888, options, function() {
    if (connection.authorized) {
        console.log('authorized');
    } else {
        console.log(':( not authorized');
    }
});

connection.on('data', function(data) {
    console.log(data);
});

