
/**
 * Using Hash Based Message Authentication
 */

var crypto = require('crypto')
    secret = 'not gonna tell you';

var hash = crypto.createHash('sha1').update('text to keep safe').digest('hex');
var hmac = crypto.createHmac('sha1', secret).update('text to keep safe').digest('hex');

console.log(hash);
console.log(hmac);

/* What you should be using is HMAC: Hash-function Message Authentication Code. You don�t need to know exactly how it works, just like you don�t need to know exactly how SHA1 works. You just need to know that HMAC is specifically built for message authentication codes and the use case of SuperAnnoyingPoke/MyFace. Under the hood, what�s approximately going on is two hashes, one after the other, with the secret combined after the first hash� but don�t worry about it! That�s the whole point! HMAC is built for this feature.

HMAC has two inputs and one output: in go a message, and a secret, and out comes a message authentication code (i.e. a signature). The security of HMAC is such that, you can see as many messages and corresponding signatures as your heart desires, and you still won�t be able to determine the signature on a message you haven�t seen yet. That�s the security property you�re looking for. And HMAC is built on top of a hash function, so more specifically you should be using HMAC-SHA1.

So, again, don�t hash secrets. HMAC them.<
*/
