var net = require('net');

var server = net.createServer(connListener);

server.listen(8181);

function connListener(conn) {

    conn.on('readable', function() {
        //read data
        console.log(this.read());
        console.log(this.remoteAddress);
        console.log(this.remotePort);
    });
    conn.on('end', function() {
        console.log('bytesWritten: ' + this.bytesWritten);
        console.log('bytesRead: ' + this.bytesRead);
    });
    conn.on('error', function( error ) {
        console.log('' + error );
    });
}
