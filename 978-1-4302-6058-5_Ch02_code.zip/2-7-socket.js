var net = require('net');

var PORT = 8181,
    totalRead = 0,
    totalWritten = 0,
    connectionCount = 0;

var server = net.Server(connectionListener);

function connectionListener(conn) {
    //tally the bytes on end
    conn.on('readable', function() {
        console.log('' + conn.read());
        conn.write('from server');
    });

    conn.on('end', function() {
        totalRead += conn.bytesRead;
    });
    //Send keepAlive packet every 500ms
    conn.setKeepAlive(true, 500);
}

server.listen(PORT);

//Connect a socket
var socket = net.createConnection(PORT);

socket.setNoDelay(false);
socket.on('data', function(data) {
    console.log('data recieved: ' + data);
});

socket.on('connect', function() {
    // plan on writing the data more than once
    connectionCount++;
    
    // My = 2 Bytes
    socket.write('My', function () {
        // Precious = 8 Bytes
        socket.pause();
        console.log('pausing...');
        socket.setTimeout(700, function() {
        // Without this the socket will never finish
            console.log('resuming...');
            socket.resume();
            socket.end('Precious');
        });
    });
});
if (connectionCount === 0) {
    for (var i = 0; i < 20; i++) {
        socket.write('buffer');
        console.log('socket buffer size: ' + socket.bufferSize);
    }
}
// tally the bytes written on end
socket.on('end', function() {
    totalWritten += socket.bytesWritten;
});

socket.on('close', function() {
    // Each time we should get +=10 bytes Read and Written
    console.log('total read: ' + totalRead);
    console.log('total written: ' + totalWritten);
    // We're gonna do this a few times
    if (connectionCount < 5) {
        socket.connect(PORT);
    } else {
        server.close();
    }
});
