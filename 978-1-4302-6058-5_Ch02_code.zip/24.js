var net = require('net');

var socket = new net.Socket();
// This will only work if there is something to connect to
// that resides on port and host
// if not the connect will throw ECONNREFUSED
socket.connect(/* port */ 8181, /*host*/ '127.0.0.1' /*, callback*/ );
