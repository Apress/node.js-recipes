/**
* Chapter 2 - Networking with Node.js
*/
var net = require('net');

// createConnection
var connection = net.createConnection({port: 8181, host:'127.0.0.1'},
// connectListener callback
    function() {
        console.log('connection successful');
});

connection.on('error', function(err) {
    console.log('connection error: ' + err);
});

connection.on('close', function() {
    console.log('connection closed');
});

connection.on('data', function(data) {
    console.log(data);
});
