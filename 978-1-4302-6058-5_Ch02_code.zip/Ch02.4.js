/**
* Chapter 2 - Networking with Node.js
*/
var net = require('net');

// createConnection
var connection = net.createConnection({port: 8181, host:'127.0.0.1'},
// connectListener callback
    function() {
        console.log('connection successful');
        console.log(connection.address());
});

connection.on('data', function(data) {
    console.log(data.toString());
    //As soon as we data, close the connection
    connection.end();
});

connection.on('error', function(error) {
    console.log(error);
});

connection.on('end', function() {
    console.log('connection ended');
});
