/**
* Chapter 2 - Networking with Node.js
*/
// 2-1: require 'net' module
var net = require('net');

//2-2: create the server with connectionListener callback
var server = net.createServer({ allowHalfOpen: true }, function(connectionListener) {
    console.log('connected');

    //Get the configured address for the server
    console.log(this.address());

    //get set maxConnections
    console.log(this.maxConnections);

    // set maxConnctions
    this.maxConnections = 1;

    // check set maxConnections
    console.log(this.maxConnections);

    //get connections takes callback function
    this.getConnections(function(err, count) {
        if (err) {
            console.log('Error getting connections');
        } else {
            console.log('Connections count: ' + count);
        }
    });
    
    connectionListener.on('end', function() {
        console.log('disconnected');
    });
    //Make sure there is something happening
    connectionListener.write('heyyo\r\n');
});

server.on('error', function(err) {
    console.log('Server error: ' + err);
});
server.on('data', function(data) {
    console.log(data.toString());
});

/**
* listen()
* accepts port, host, backlog, and callback
*/
server.listen(8181, '::1', 12, function() {
    console.log(server.address());
});
