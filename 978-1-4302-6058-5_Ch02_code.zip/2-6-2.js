var net = require('net');

var socket = new net.Socket(/* fd: null, type: null, allowHalfOpen: false */);

socket.connect(8181, '127.0.0.1' /*, connectListener  replaces on('connect') */);
socket.setEncoding('utf16le'); /* utf8, utf16le, ucs2, ascii, hex */

socket.on('connect', function() {
    console.log('connected to: ' + this.remoteAddress);
    var obj = { name: 'Frodo', occupation: 'adventurer' };
    this.write(JSON.stringify(obj));
});

socket.setTimeout(2e3 /* milliseconds */ , function() { 
    console.log('timeout completed'); 
    var obj = { name: 'timeout', message: 'I came from a timeout'};
    this.write(JSON.stringify(obj), function() {
        socket.end();
    }); 
});

socket.on('end', function() {
    console.log('bytesWritten: ' + this.bytesWritten);
    console.log('bytesRead: ' + this.bytesRead);
});

socket.on('error', function(error) {
    console.log('' + error);
    // Don't persist this socket if there is a connection error
    socket.destroy();
});

socket.on('data', function(data) {
    console.log('from server: ' + data);
});
