var net = require('net');

var serverConnection;
var server = net.createServer(function(connection) {
    serverConnection = connection;
    connection.setTimeout(0);
    connection.setKeepAlive(true, 500);
    connection.on('end', function() {
        connection.end();
    });
});

server.listen(8181, function() {
    var clientConnection = net.createConnection(8181);
    clientConnection.setTimeout(0);

    setTimeout(function() {
        // these should be open 
        console.log(serverConnection.readyState);
        console.log(clientConnection.readyState);
        serverConnection.end();
        clientConnection.end();
        // read only
        console.log(serverConnection.readyState);
        console.log(clientConnection.readyState);
        server.close();

    }, 700);
});
