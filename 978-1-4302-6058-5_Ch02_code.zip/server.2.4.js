var net = require('net');

var server = net.createServer(function(connectionListener) {
    //get connection count
    if (typeof this.getConnections !== "undefined") {
        this.getConnections(function(err, count) {
            if (err) {
                console.log('Error getting connections');
            } else {
                // send out info for this socket
                connectionListener.write('connections to server: ' + count + '\r\n');
            }
        });
    }

    connectionListener.on('end', function() {
        console.log('disconnected');
    });
    connectionListener.setEncoding();
    //Make sure there is something happening
    connectionListener.write('heyo\r\n');

    // Handle connection errors
    connectionListener.on('error', function(err) {
        console.log('server error: ' + err);
    });

    connectionListener.on('readable', function() {
        console.log(this.read()); // Stream.readable
    });
    connectionListener.on('data', function(data) {
        console.log('message for you sir: ' + data);
    });
});

server.on('error', function(err) {
    console.log('Server error: ' + err);
});

server.on('data', function(data) {
    console.log(data.toString());
});

server.listen(8181, function() {
    console.log('server is listening');
});
