var http = require('http');

var getReq = http.get('http://localhost:8080', function(res) {
  console.log('status code', res.statusCode, ': ', http.STATUS_CODES[res.statusCode]);
});

getReq.on('error', function(err) {
	console.log(err);
});