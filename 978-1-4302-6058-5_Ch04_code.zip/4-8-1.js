/*
* Creating an HTTP client
*/

var http = require('http');

var clientOptions = {
  host: 'localhost',
  port: '8080',
  path: '/',
  method: 'GET',
  headers: { 'Connection': 'keep-alive',
							'Content-Length': 0 }
};

var clientReq = http.request(clientOptions, function(res) {
  console.log('status code', res.statusCode, ': ', http.STATUS_CODES[res.statusCode]);
  res.on('data', function(data) {
  	console.log(data);
  })
});

clientReq.on('continue', function(res) {
	console.log('continue event due to 100-continue');
});

clientReq.on('error', function(error) {
  throw error;
});

clientReq.end();
