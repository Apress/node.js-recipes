var http = require('http');

var opt = {
	host : 'localhost',
	port : 8080,
	path : '/upload',
	method : 'POST'
};

var upload = http.request(opt, function(res) {
	console.log('status code', res.statusCode, ': ', http.STATUS_CODES[res.statusCode]);
});

upload.on('error', function(err) {
	console.log(err);
});

upload.write('my upload stuff');
upload.end();