/*
* client events
*/

var http = require('http');

var clientOptions = {
	host: 'localhost',
	// hostname:'nodejs.org',
	port: '8080',
	path: '/',
	method: 'GET',
	headers: { 'Connection': 'Upgrade',
	'Upgrade': 'websocket',
	'Sec-WebSocket-Key': 'dGhlIHNhbXBsZSBub25jZQ==',
	'Origin' :'localhost',
	'Sec-WebSocket-Protocol': 'chat',
	'Sec-WebSocket-Version': 13 }
};

var clientReq = http.request(clientOptions, function(res) {
	console.log('status code', res.statusCode);
	switch(res.statusCode) {
		case 200:
			res.setEncoding('utf8'); // unless you can read buffer chunks
			res.on('data', function(data) {
				console.log('data', data);
			});
			break;
		case 404:
			console.log('404 error');
			break;
	}
});

clientReq.on('upgrade', function(res, socket, head) {
	console.log('client upgrade');
});

clientReq.on('error', function(error) {
	throw error;
});

clientReq.end();