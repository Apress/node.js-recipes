/**
* Global event
*/
var ext = require('./5-1-5.js');

process.on('globalEvent', function() {
	console.log('global event');
});

ext.emitEvent();
