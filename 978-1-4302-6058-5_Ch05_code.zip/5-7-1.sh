#!/bin/sh
echo "running this shell script from child_process.execFile"
# run another node process
node 5-6-1.js
# and another
node 5-5-1.js

ps ax | grep node