/**
* External Module
*/
module.exports = function(emitter) {
	emitter.on('custom', function() {
		console.log('bazinga');
	});
};
