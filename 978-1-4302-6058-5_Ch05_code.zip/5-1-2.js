/**
* Custom Events
*/

var events = require('events'),
	emitter = new events.EventEmitter(),
	myModule = require('./5-1-3.js')(emitter);

emitter.on('custom', function() {
	console.log('custom event received');
});

emitter.emit('custom');

