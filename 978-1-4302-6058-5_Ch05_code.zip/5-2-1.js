/**
* Memory Leak Warning
*/

var events = require('events'),
		emitter = new events.EventEmitter(),
		listener = function() {
			console.log('event happened');
		};

emitter.on('evt', listener);
emitter.on('evt', listener);
emitter.on('evt', listener);
emitter.on('evt', listener);
emitter.on('evt', listener);
emitter.on('evt', listener);
emitter.on('evt', listener);
emitter.on('evt', listener);
emitter.on('evt', listener);
emitter.on('evt', listener);
emitter.on('evt', listener);
emitter.on('evt', listener);

emitter.emit('evt');