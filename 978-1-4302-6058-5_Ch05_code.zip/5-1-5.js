

var myMod = module.exports = {
	emitEvent: function() {
		process.emit('globalEvent');
	}
};
