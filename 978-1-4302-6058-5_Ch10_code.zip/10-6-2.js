var nano = require('nano')('http://localhost:5984');


nano.request({
	db: 'products',
	doc: 'sandals',
	method: 'get'
	}, function(err, body, header) {
		if (err) console.log('request::err', err);
		console.log('request::body', body);
	});
//nano.db.destroy('products');
var products = nano.db.use('products');
// deleting in couchDB with Nano.
products.get('sandals', function(err, body, header) {
	if (!err) {
		products.destroy( 'sandals', body._rev, function(err, body, header) {
			if (!err) {
				console.log(body, header);
			}
			nano.db.destroy('products');
		});
	}
});

