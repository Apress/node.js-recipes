var helenus = require('helenus'),
    pool = new helenus.ConnectionPool({
       hosts      : ['127.0.0.1:9160'],
        keyspace   : 'my_ks',
        user       : 'username',
        password   : 'pass',
        timeout    : 3000//,
        //cqlVersion : '3.0.0' // specify this if you're using Cassandra 1.1 and want to use CQL 3 
    });

var logger = module.exports = {
    /** 
    * Logs data to the Cassandra cluster
    * 
    * @param status     the status event that you want to log
    * @param message    the detailed message of the event
    * @param stack      the stack trace of the event
    * @param callback   optional callback
    */
    log: function(status, message, stack, callback) {
        pool.connect(function(err, keyspace){
            keyspace.get('logger', function(err, cf) {
                var dt = Date.parse(new Date());
                //Create a column
                var column = {};
                column['time'] = dt;
                column['status'] = status;
                column['message'] = message;
                column['stack'] = stack;

                var timeUUID = helenus.TimeUUID.fromTimestamp(new Date());
                var cqlInsert = 'INSERT INTO logger (log_time, time, status, message,stack)' +
                                'VALUES ( %s, %s, %s, %s, %s )';

                var cqlParams = [ timeUUID, column.time, column.status, column.message, column.stack ];
                pool.cql(cqlInsert, cqlParams, function(err, results) {
                    if (err) logger.log('ERROR', JSON.stringify(err), err.stack);
                });
            });
        });
    }
};


var timeUUID = helenus.TimeUUID.fromTimestamp(new Date()) + '';
                    var cqlInsert = 'INSERT INTO hx_services_pha_card (card_id, card_definition_id, pig_query, display_template, tokens, trigger)' +
                                    'VALUES ( %s, %s, %s, %s, %s, %s )';
                                    // 'VALUES (\'' + timeUUID + '\',\'' + queueObj.card_definition_id + '\',\'' + queueObj.pig_query + '\',\'' + queueObj.display_template + '\',\'' + tokens.join(',') + '\',\'' + queueObj.trigger + '\') ';
                    var cqlParams = [ timeUUID, queueObj.card_definition_id, queueObj.pig_query, queueObj.display_template, tokens.join(','), queueObj.trigger ];
                    pool.cql(cqlInsert, cqlParams, function(err, results) {
                        if (err) logger.log('ERROR', JSON.stringify(err), err.stack);
                    });