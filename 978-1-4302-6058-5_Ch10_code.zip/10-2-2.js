/*
* Using MS SQL
*/

var TDS = require('tedious'),
	Conn = TDS.Connection,
	aModel = require('./10-2-1.js');

var conn = new Conn({
		username: 'sa'
		password: 'pass',
        server: 'localhost',
        options: {
            database: 'Northwind',
            rowCollectionOnRequestCompletion: true
        }
    });

function handleResult(err, res) {
	if (err) throw err;
	console.log(res);
}

conn.on('connect', function(err) {
	if (err) throw err;

	aModel.getByParameter(conn, 'parameter', handleResult);

	aModel.getByParameterSP(conn, 'parameter', handleResult);
});


