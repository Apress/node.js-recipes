/**
* RIAK
*/

var db = require('riak-js').getClient({ host: 'localhost', port: 8098});

db.exists('products', 'huaraches', function(err, exists, meta) {
	if (exists) {
		db.remove('products', 'huaraches', function(err, value, meta) {
			if (err) console.log(err);
			console.log('removed huaraches');
		});
	}
});

db.save('products', 'flops', { name: 'flip flops', description: 'super for your feet', price: 12.50}, function(err) {
	if (err) console.log(err);
	console.log('flip flops created');
	process.emit('prod');
});

db.save('products', 'flops', 'flip flops',function(err) {
	if (err) console.log(err);
	console.log('flip flops created');
	process.emit('prod');
});

db.save('products', 'huaraches', {name: 'huaraches', description: 'more fun for your feet', price: 20.00}, function(err) {
	if (err) console.log(err);

	console.log('huaraches created');
	process.emit('prod');

	db.get('products', 'huaraches', function(err, value, meta) {
		if (err) console.log(err);
		console.log(value, meta);
	});

});

process.on('prod', function() {

	db.getAll('products', function(err, value, meta) {
		if (err) console.log(err);
		console.log(value);
	});

});

db.mapreduce
	.add('products')
	.map(function(v) {
		return [Riak.mapValuesJson(v)[0]];
	})
	.run(function(err, value, meta) {
		console.log(value);
	});