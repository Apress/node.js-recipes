/**
* PostgreSQL
*/

var pg = require('pg');

var connectionString = 'tcp://postgres:pass@localhost/postgres';

var client = new pg.Client(connectionString);

client.connect(function(err) {
	if (err) throw err;

	client.query('SELECT EXTRACT(CENTURY FROM TIMESTAMP "2000-12-16 12:21:13")', function(err, result) {
		if (err)  throw err;

		console.log(result.rows[0]);

		client.end();
	});
});