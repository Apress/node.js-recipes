/**
* mongo helpers
*/

var mongoose = require('mongoose');


exports.initDB = function(callback)  {
	mongoose.connection.on( 'open' , function(){
		console.log("mongoose init");
		callback();
	});
	mongoose.connect('mongodb://localhost/test');
};

exports.query =  function(collectionIdent, json, callback) {
	console.log('hey');
    mongoose.connection.db.collection(collectionIdent, function (err, collection) {
        collection.find(json).toArray(callback);
    });
};

exports.insert = function(collectionIdent, json, callback) {
    mongoose.connection.db.collection(collectionIdent, function (err, collection) {
        collection.insert(json);
	});
};