/**
* mysql
*/

var mysql = require('mysql');

var connectionConfig = {
	host: 'localhost',
	user: 'root',
	password: 'password',
	database: 'sakila'	
};

var connection = mysql.createConnection(connectionConfig);


connection.connect(function(err) {
	console.log('connection::connected');
});

var query = connection.query('SELECT * FROM actor');

query.on('error', function(err) {

	console.log(err);

}).on('fields', function(fields) {

	console.log(fields);

}).on('result', function(row) {
	connection.pause();
	console.log(row);
	connection.resume();
}).on('end', function(err) {
	console.log('connection::end');
});
