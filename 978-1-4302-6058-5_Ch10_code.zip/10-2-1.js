var TDS = require('tedious'),
	TYPES = TDS.TYPES,
	Request = TDS.Request;
var aModel = module.exports = {
	// Use vanilla SQl
	getByParameter: function(conn, parm, callback) {
		var q = 'select * from model (NOLOCK) where identifier = @parm';

		var req = new Request(q, function(err, rowcount, rows) {
			callback( err, rows );
		});
		req.addParameter('parm', TYPES.UniqueIdentifierN, parm);

		conn.execSql(req);
	},
	// Use a Store Procedure
	getByParameterSP: function(conn, parm, callback) {
		var q = 'exec sp_getModelByParameter @parm';	
		var req = new Request(q, function(err, rowcount, rows) {
			callback( err, rows );
		});
		req.addParameter('parm', TYPES.UniqueIdentifierN, parm);

		conn.execSql(req);
	}
};

