/**
* Modeling data with Mongoose
*/

var mongoose = require('mongoose'),
	Schema = mongoose.Schema,
	ObjectId = Schema.ObjectId;
	db = require('./10-5-2.js');


var productModel = new Schema({
	productId: ObjectId,
	name: String,
	description: String,
	price: Number
});


db.initDB(function() {
	var Product = mongoose.model('Product', productModel);
	db.query('Product', { name: 'sandal'}, function(err, result) {
		if (err) console.log(err);

		console.log(result);
	});
});
