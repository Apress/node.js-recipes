/**
* Pub/Sub 
*/
var redis = require("redis"),
    subscriber = redis.createClient(),
    publisher = redis.createClient();

subscriber.on("subscribe", function (topic, count) {
    publishers.publish("event topic", "your event has occured");
});

subscriber.on("message", function (topic, message) {
    console.log("message recieved:: " + topic + ": " + message);
    subscriber.end();
    publisher.end();
});

subscriber.subscribe("event topic");