var helenus = require('helenus'),
    pool = new helenus.ConnectionPool({
       hosts      : ['127.0.0.1:9160'],
        keyspace   : 'my_ks',
        user       : 'username',
        password   : 'pass',
        timeout    : 3000//,
        //cqlVersion : '3.0.0' // specify this if you're using Cassandra 1.1 and want to use CQL 3 
    });

var logger = module.exports = {
    /** 
    * Logs data to the Cassandra cluster
    * 
    * @param status     the status event that you want to log
    * @param message    the detailed message of the event
    * @param stack      the stack trace of the event
    * @param callback   optional callback
    */
    log: function(status, message, stack, callback) {
        pool.connect(function(err, keyspace){
            keyspace.get('logger', function(err, cf) {
                var dt = Date.parse(new Date());
                //Create a column
                var column = {};
                column['time'] = dt;
                column['status'] = status;
                column['message'] = message;
                column['stack'] = stack;

                var timeUUID = helenus.TimeUUID.fromTimestamp(new Date());

                cf.insert(timeUUID, column, function(err) {
                    if (err) {
                        console.log('error', err);
                    }
                    if (callback) {
                        callback();
                    } else {
                        return;
                    }

                });
            });
        });
    }
};
