/**
* Buffer
*/

var buffer = new Buffer(16);
console.log('size init', buffer.toString());

buffer = new Buffer([42, 41, 41, 41, 41, 41, 41, 42, 42,4, 41, 41, 0, 0, 7, 77]);
console.log('array init', buffer.toString());

buffer = new Buffer('hello buffer', 'ascii');
console.log(buffer.toString());

buffer = new Buffer('hello buffer', 'ucs2');
console.log(buffer.toString());

buffer = new Buffer('hello buffer', 'base64');
console.log(buffer.toString());

buffer = new Buffer('hello buffer', 'binary');
console.log(buffer.toString());

console.log(JSON.stringify(buffer));
console.log(buffer[1]);
console.log(Buffer.isBuffer('not a buffer'));
console.log(Buffer.isBuffer(buffer));
// allocate size
var buffer = new Buffer(16);
// write to a buffer
console.log(buffer.write('hello again', 'utf-8'));
// append more starting with an offset
console.log(buffer.write(' wut', 11, 'utf8'));
console.log(buffer.toString());
// slice [start, end]
buf = buffer.slice(11, 15);

console.log(buf.toString());
console.log(buffer.length);

console.log(buffer.readUInt8(0));
console.log(buffer.readUInt16LE(0));
console.log(buffer.readUInt16BE(0));
console.log(buffer.readUInt32LE(0));
console.log(buffer.readUInt32BE(0));
console.log(buffer.readInt16LE(0));
console.log(buffer.readInt16BE(0));
console.log(buffer.readInt32LE(0));
console.log(buffer.readInt32BE(0));
console.log(buffer.readFloatLE(0));
console.log(buffer.readFloatBE(0));
console.log(buffer.readDoubleLE(0));
console.log(buffer.readDoubleBE(0));

buffer.fill('4');

console.log(buffer.toString());

var b1 = new Buffer(4);
var b2 = new Buffer(4);
b1.fill('1');
b2.fill('2');

console.log(b1.toString());
console.log(b2.toString());

b2.copy(b1, 2, 2, 4);

console.log(b1.toString());
