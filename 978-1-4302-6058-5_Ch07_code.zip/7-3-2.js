/**
* Clustering
*/

var cluster = require('cluster'),
		cpuCount = require('os').cpus().length;

cluster.setupMaster({
	exec: '7-3-3.js'
});
if (cluster.isMaster) {
	for (var i = 0; i < cpuCount; i++) {
		cluster.fork();
	}
	cluster.on('fork', function(worker) {
		console.log(worker.process.id + ' worker is forked');
	});
	cluster.on('listening', function(worker, address) {
		console.log(worker.process.id + ' is listening on ' + address.address + ':' + address.port);
		worker.send('wut');
	});
	cluster.on('online', function(worker) {
		console.log(worker.process.id + ' is online');
	});
	cluster.on('setup', function(worker) {
		console.log(worker.process.id + ' setup');
	});
	cluster.on('disconnect', function(worker) {
		console.log(worker.process.id + ' disconnected');
	});
	cluster.on('exit', function(worker, code, signal) {
    console.log('worker ' + worker.process.pid + ' died');
  });
}