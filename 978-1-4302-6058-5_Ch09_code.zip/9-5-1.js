/**
* Getting started with ExpressJS
*/

var express = require('express'),
	app = express();

// use middleware
app.use(express.logger());
app.use(express.compress());
app.use(express.static(__dirname));
app.use(express.basicAuth(function(username, password) {
	return username == 'shire' & password == 'baggins';
}));
// a simple route
app.get('/blah', function(req, res, next) {
	next(new Error('failing route'));
	res.send(app.get('blah'));
});

// a default handler
app.use(function(req, res) {
	res.send(app.get('default'));
});


app.use(function(err, req, res, next){
  console.error(err.stack);
  res.send(500, 'Something broke!');
});

// configurations

app.configure('development', function() {
	app.set('default', 'express development site');
	app.set('blah', 'blah blah blah');
});

app.configure('production', function() {
	app.set('default', 'express production site');
});
// app.engine('jade', require('jade').__express);

app.listen(3000); // same as http.server.listen

