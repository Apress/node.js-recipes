
/**
 * Module dependencies.
 */

var express = require('express')
  , routes = require('./routes')
  , http = require('http')
  , path = require('path');

var app = express();

// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', __dirname + '/views');
app.set('view engine', 'jade');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.bodyParser());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}
var products = [
	{ name: 'watch', description: 'Tell time with this amazing watch', price: 30.00 },
	{ name: 'sandals', description: 'Walk in comfort with these sandals', price: 10.00 },
	{ name: 'sunglasses', description: 'Protect your eyes in style', price: 25.00 }
];

app.get('/', routes.index);
// curl -X GET http://localhost:3000/products
app.get('/products', function(req, res) {
	res.json(products);
});
// curl -X GET http://localhost:3000/products/2
app.get('/products/:id', function(req, res) {
	if (req.params.id > (products.length - 1) || req.params.id < 0) {
		res.statusCode = 404;
		res.end('Not Found');
	}
	res.json(products[req.params.id]);
});
// curl -X POST -d "name=flops&description=sandals&price=12.00" http://localhost:3000/products
app.post('/products', function(req, res) {
	if (typeof req.body.name === 'undefined') {
		res.statusCode = 400;
		res.end('a product name is required');
	} 
	products.push(req.body);
	res.send(req.body);
});
// curl -X PUT -d "name=flipflops&description=sandals&price=12.00" http://localhost:3000/products/3
app.put('/products/:id', function(req, res) {
	if (req.params.id > (products.length -1) || req.params.id < 0) {
		res.statusCode = 404;
		res.end('No product found for that ID');
	}
	products[req.params.id] = req.body;
	res.send(req.body);
});
// curl -X DELETE http://localhost:3000/products/2
app.delete('/products/:id', function(req, res) { 
	if (req.params.id > (products.length - 1) || req.params.id < 0) {
		req.statusCode = 404;
		res.end('No product found for that ID');
	}
	products.splice(req.params.id, 1);
	res.json(products);
});

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});
